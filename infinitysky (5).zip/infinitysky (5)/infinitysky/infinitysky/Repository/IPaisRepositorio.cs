﻿using infinitysky.Models;

namespace infinitysky.Repository
{
    public interface IPaisRepositorio
    {
        Pais ObterPais(int Id);
        //Pais Find(int Id);
    }
}
