﻿namespace infinitysky.Models
{
    public class PlanosPrimeiraParte
    {
        public IEnumerable<Planos> TresPrimeirosPlanos { get; set; }

        public IEnumerable<Planos> RestantePlanos { get; set; }
    }
}
