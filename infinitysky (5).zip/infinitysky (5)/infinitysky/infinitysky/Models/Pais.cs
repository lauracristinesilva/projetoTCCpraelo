﻿namespace infinitysky.Models
{
    public class Pais
    {
            public int IdPais { get; set; } 
            public string NomePais { get; set; } 
            public string ClimaPais { get; set; } 
            public string ComidasTip { get; set; } 
            public string MoedaPais { get; set; } 
            public string DescricaoPais { get; set; } 
            public string image_pais { get; set; }
            public string image_clima { get; set; }
            public string image_comida { get; set; }
            public string image_moeda { get; set; }



    }
}
