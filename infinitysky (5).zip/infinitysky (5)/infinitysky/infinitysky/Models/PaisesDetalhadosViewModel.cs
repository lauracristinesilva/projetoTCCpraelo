﻿using System.Numerics;

namespace infinitysky.Models
{
    public class PaisesDetalhadosViewModel
    {
        
            public Pais Pais { get; set; }
            public List<Planos> Planos { get; set; }


    }
}
